// Определяем константу для действия увеличения счетчика
export const INCREMENT_COUNTER = 'INCREMENT_COUNTER';
// Определяем константу для действия уменьшения счетчика
export const DECREMENT_COUNTER = 'DECREMENT_COUNTER';

export const incrementCounter = () => ({
  type: INCREMENT_COUNTER,
});

export const decrementCounter = () => ({
  type: DECREMENT_COUNTER,
});