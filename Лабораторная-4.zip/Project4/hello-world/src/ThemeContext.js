import React, { createContext, useState, useContext } from 'react';

// Создаем контекст для темы
const ThemeContext = createContext();

// Кастомный хук для управления темой (теперь используется внутри провайдера)
/**
 * Кастомный хук для управления темой приложения.
 * Сохраняет выбранную тему в localStorage для сохранения между сессиями.
 * 
 * @returns {Object} Объект с текущей темой и функцией для её переключения
 * @property {string} theme - Текущая тема ('light' или 'dark')
 * @property {function} toggleTheme - Функция для переключения темы
 */
const useTheme = () => {
  // Инициализация состояния темы
  // При первом рендере пытаемся получить тему из localStorage,
  // если её нет - используем 'light' по умолчанию
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('theme') || 'light';
  });

  // Эффект для сохранения темы в localStorage при её изменении
  // Срабатывает каждый раз, когда изменяется значение theme
  

  /**
   * Функция для переключения темы
   * Меняет текущую тему на противоположную:
   * 'light' -> 'dark' или 'dark' -> 'light'
   */
  const toggleTheme = () => {
    // Используем функциональную форму setState,
    // чтобы гарантированно получить актуальное предыдущее значение
    setTheme((prevTheme) => {
      const newTheme = prevTheme === 'light' ? 'dark' : 'light';
      
      // Сохраняем новый theme в localStorage
      localStorage.setItem('theme', newTheme);
      
      // Возвращаем новый theme
      return newTheme;
    });
  };

  // Возвращаем текущую тему и функцию для её переключения
  return { theme, toggleTheme };
};

// Провайдер для темы (упрощенная версия)
const ThemeProvider = ({ children }) => {
  const value = useTheme();
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

// Экспортируем контекст, провайдер и готовый хук для использования
export { ThemeContext, ThemeProvider, useTheme };

// Дополнительно можно экспортировать готовый хук для потребителей
export const useThemeContext = () => useContext(ThemeContext);


