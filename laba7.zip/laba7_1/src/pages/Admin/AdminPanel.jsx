// src/pages/AdminPanel.jsx
/*import React, { useEffect, useState } from "react";
import UserTable from '../../components/UserTable/UserTable';
import FeedbackAdmin from '../../components/FeedbackAdmin'; // обратная связь для администраторов

const AdminPanel = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    // Здесь вы можете запросить пользователей из API
    const fetchUsers = async () => {
      const response = await fetch('/api/users'); // заменить на ваш API
      const data = await response.json();
      setUsers(data);
    };
    fetchUsers();
  }, []);

  const handleDelete = (id) => {
    // Логика удаления пользователя
    console.log(`Delete user with ID: ${id}`);
  };

  const handleBlock = (id) => {
    // Логика блокировки пользователя
    console.log(`Block user with ID: ${id}`);
  };

  const columns = [
    { Header: 'Имя', accessor: 'name' },
    { Header: 'Email', accessor: 'email' },
    { Header: 'Роль', accessor: 'role' },
    { Header: 'Действия', accessor: 'actions' },
  ];

  return (
    <div>
      <h1>Панель администрирования</h1>
      <UserTable columns={columns} data={users} onDelete={handleDelete} onBlock={handleBlock} />
      <FeedbackAdmin />
    </div>
  );
};

export default AdminPanel;*/

/*import React, { useState } from "react";
import UserTable from '../../components/UserTable/UserTable';
import FeedbackAdmin from '../../components/FeedbackAdmin';

const AdminPanel = () => {
  // Тестовые данные
  const [users] = useState([
    { id: 1, name: 'Администратор', email: 'admin@test.com', role: 'admin' },
    { id: 2, name: 'Пользователь', email: 'user@test.com', role: 'user' }
  ]);

  const columns = [
    { accessorKey: 'name', header: 'Имя' },
    { accessorKey: 'email', header: 'Email' },
    { accessorKey: 'role', header: 'Роль' }
  ];

  const handleDelete = (id) => {
    console.log(`Удалить пользователя ${id}`);
    // Здесь будет логика удаления
  };

  const handleBlock = (id) => {
    console.log(`Заблокировать пользователя ${id}`);
    // Здесь будет логика блокировки
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Панель администрирования</h1>
      <div style={{ marginBottom: '40px' }}>
        <UserTable 
          columns={columns} 
          data={users} 
          onDelete={handleDelete}
          onBlock={handleBlock} 
        />
      </div>
      <FeedbackAdmin />
    </div>
  );
};

export default AdminPanel;*/
import React, { useState, useEffect } from 'react';
import UserTable from '../../components/UserTable/UserTable';
import FeedbackAdmin from '../../components/FeedbackAdmin';

const AdminPanel = () => {
  const [users, setUsers] = useState([]);
  const [feedback, setFeedback] = useState([]);

  useEffect(() => {
    // Загрузка данных
    const loadData = async () => {
      const usersResponse = await fetch('/api/users');
      const feedbackResponse = await fetch('/api/feedback');
      setUsers(await usersResponse.json());
      setFeedback(await feedbackResponse.json());
    };
    loadData();
  }, []);

  const handleDeleteUser = async (id) => {
    await fetch(`/api/users/${id}`, { method: 'DELETE' });
    setUsers(users.filter(user => user.id !== id));
  };

  const handleBlockUser = async (id) => {
    const updatedUsers = users.map(user => 
      user.id === id ? { ...user, isBlocked: !user.isBlocked } : user
    );
    setUsers(updatedUsers);
    await fetch(`/api/users/${id}/block`, { method: 'POST' });
  };

  const columns = [
    { Header: 'ID', accessor: 'id' },
    { Header: 'Имя', accessor: 'name' },
    { Header: 'Email', accessor: 'email' },
    { Header: 'Роль', accessor: 'role' },
    { Header: 'Статус', accessor: 'status' },
  ];

  return (
    <div className="admin-panel">
      <h1>Панель администратора</h1>
      
      <section className="users-section">
        <h2>Управление пользователями</h2>
        <UserTable 
          columns={columns} 
          data={users} 
          onDelete={handleDeleteUser}
          onBlock={handleBlockUser}
        />
      </section>

      <section className="feedback-section">
        <h2>Управление обратной связью</h2>
        <FeedbackAdmin 
          feedback={feedback} 
          onDelete={id => setFeedback(feedback.filter(f => f.id !== id))}
        />
      </section>
    </div>
  );
};

export default AdminPanel;