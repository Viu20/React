import React, { useState } from 'react';
import {
  Modal,
  Box,
  TextField,
  Button,
  Tabs,
  Tab,
  Alert
} from '@mui/material';

const modalStyle = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: 4,
  borderRadius: 2
};

// Вспомогательная функция для безопасной работы с localStorage
const safeStorage = {
  get: (key, defaultValue = null) => {
    try {
      const item = localStorage.getItem(key);
      if (item === null || item === 'undefined') return defaultValue;
      return JSON.parse(item);
    } catch (error) {
      console.error(`Error parsing ${key} from localStorage:`, error);
      return defaultValue;
    }
  },
  set: (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error(`Error saving ${key} to localStorage:`, error);
    }
  }
};

export default function AuthModal({ open, onClose, onLoginSuccess }) {
  const [tabValue, setTabValue] = useState(0);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const resetForm = () => {
    setEmail('');
    setName('');
    setPassword('');
    setError('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    if (tabValue === 0) {
      // Логика входа
      const users = safeStorage.get('users', []);
      const user = users.find(u => u.email === email && u.password === password);
      
      if (user) {
        console.log('User data to save (login):', user);
        console.log('Stringified user:', JSON.stringify(user));
        
        safeStorage.set('currentUser', user);
        onLoginSuccess(user);
        onClose();
        resetForm();
      } else {
        setError('Неверные email или пароль');
      }
    } else {
      // Логика регистрации
      if (!name || !email || !password) {
        setError('Все поля обязательны');
        return;
      }

      const users = safeStorage.get('users', []);
      
      if (users.some(u => u.email === email)) {
        setError('Пользователь с таким email уже существует');
        return;
      }

      const newUser = { 
        name: name.trim(), 
        email: email.trim().toLowerCase(), 
        password 
      };

      console.log('User data to save (register):', newUser);
      console.log('Stringified user:', JSON.stringify(newUser));

      const updatedUsers = [...users, newUser];
      
      safeStorage.set('users', updatedUsers);
      safeStorage.set('currentUser', newUser);
      onLoginSuccess(newUser);
      onClose();
      resetForm();
    }
  };

  return (
    <Modal open={open} onClose={() => {
      onClose();
      resetForm();
    }}>
      <Box sx={modalStyle}>
        <Tabs 
          value={tabValue} 
          onChange={(e, newVal) => {
            setTabValue(newVal);
            setError('');
          }} 
          centered
        >
          <Tab label="Вход" />
          <Tab label="Регистрация" />
        </Tabs>

        {error && <Alert severity="error" sx={{ my: 2 }}>{error}</Alert>}

        <Box component="form" onSubmit={handleSubmit}>
          {tabValue === 1 && (
            <TextField
              label="Имя"
              fullWidth
              margin="normal"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          )}

          <TextField
            label="Email"
            type="email"
            fullWidth
            margin="normal"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <TextField
            label="Пароль"
            type="password"
            fullWidth
            margin="normal"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            inputProps={{ minLength: 6 }}
          />

          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3 }}
          >
            {tabValue === 0 ? 'Войти' : 'Зарегистрироваться'}
          </Button>
        </Box>
      </Box>
    </Modal>
  );
}