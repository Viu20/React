// src/components/FeedbackRead.jsx
import React from "react";

const FeedbackRead = ({ feedback }) => {
  return (
    <div>
      <h2>Обратная связь</h2>
      {feedback.map(item => (
        <div key={item.id}>
          <p>{item.message}</p>
        </div>
      ))}
    </div>
  );
};

export default FeedbackRead;
