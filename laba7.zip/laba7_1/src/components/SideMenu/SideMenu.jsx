import React from 'react';
import { 
  Drawer, 
  List, 
  ListItem, 
  ListItemIcon, 
  ListItemText,
  Divider 
} from '@mui/material';
import ScienceIcon from '@mui/icons-material/Science';
import { Link } from 'react-router-dom';

const labs = [
  { id: 1, name: 'Лабораторная работа 1', path: '/lab1' },
  { id: 2, name: 'Лабораторная работа 2', path: '/lab2' },
  { id: 3, name: 'Лабораторная работа 3', path: '/lab3' },
  { id: 4, name: 'Лабораторная работа 4', path: '/lab4' },
  { id: 5, name: 'Лабораторная работа 5', path: '/lab5' },
  { id: 6, name: 'Лабораторная работа 6', path: '/lab6' },
  { id: 7, name: 'Лабораторная работа 7', path: '/lab7' },
  { id: 8, name: 'Лабораторная работа 8', path: '/lab8' },
  { id: 9, name: 'Лабораторная работа 9', path: '/lab9' },
];

export default function SideMenu({ open, setOpen }) {
  const handleClose = () => setOpen(false);

  return (
    <Drawer anchor="left" open={open} onClose={handleClose}>
      <div style={{ width: 250 }}>
        <List>
          <ListItem>
            <ListItemText 
              primary="Лабораторные работы" 
              primaryTypographyProps={{ fontWeight: 'bold' }}
            />
          </ListItem>
          <Divider />
          
          {labs.map((lab) => (
            <ListItem 
              button 
              key={lab.id}
              component={Link}
              to={lab.path}
              onClick={handleClose}
            >
              <ListItemIcon>
                <ScienceIcon />
              </ListItemIcon>
              <ListItemText primary={lab.name} />
            </ListItem>
          ))}
        </List>
      </div>
    </Drawer>
  );
}