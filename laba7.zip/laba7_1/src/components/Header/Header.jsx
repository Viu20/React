import React from 'react';
import { 
  AppBar, 
  Toolbar, 
  IconButton, 
  Button, 
  Typography, 
  Switch 
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';

const Header = ({ 
  darkMode, 
  setDarkMode, 
  setMenuOpen, 
  currentUser, 
  onLoginClick, 
  onLogoutClick 
}) => {
  return (
    <AppBar position="static" color="secondary">
      <Toolbar>
        <IconButton
          edge="start"
          color="inherit"
          aria-label="menu"
          onClick={() => setMenuOpen(true)}
          sx={{ mr: 2 }}
        >
          <MenuIcon />
        </IconButton>

        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Лабораторные работы по Web-программированию
        </Typography> 

        <Switch
          checked={darkMode}
          onChange={() => setDarkMode(!darkMode)}
          color="default"
        />

        {currentUser ? (
          <>
            <Typography variant="subtitle1" sx={{ mr: 2 }}>
              {currentUser.name}
            </Typography>
            <Button color="inherit" onClick={onLogoutClick}>
              Выйти
            </Button>
          </>
        ) : (
          <Button color="inherit" onClick={onLoginClick}>
            Войти
          </Button>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Header;