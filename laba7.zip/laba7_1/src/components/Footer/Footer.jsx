import React from 'react';
import { 
  BottomNavigation, 
  BottomNavigationAction,
  Paper
} from '@mui/material';
import FeedbackIcon from '@mui/icons-material/Feedback';
import { useNavigate } from 'react-router-dom';

export default function Footer() {
  const navigate = useNavigate();

  return (
    <Paper sx={{ position: 'fixed', bottom: 0, left: 0, right: 0 }} elevation={3}>
      <BottomNavigation showLabels>
        <BottomNavigationAction
          label="Отзывы"
          icon={<FeedbackIcon />}
          onClick={() => navigate('/feedback')}
        />
      </BottomNavigation>
    </Paper>
  );
}