// src/components/FeedbackAdmin.jsx
import React from "react";

const FeedbackAdmin = () => {
  // Здесь вы можете реализовать логику отображения всех сообщений обратной связи
  return (
    <div>
      <h2>Обратная связь</h2>
      {/* Логика для отображения обратной связи */}
    </div>
  );
};

export default FeedbackAdmin;
