import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { Header } from './components/Header';
import { HomePage } from './pages/HomePage';
import { LoginPage } from './pages/LoginPage';
import { RegistrationPage } from './pages/RegistrationPage';
import useLoginState from './hooks/useLoginState';

function App() {
    const { isLoggedIn, setLoginState, loading: authLoading } = useLoginState(); // Переименовали loading от useLoginState
    const [feedbacks, setFeedbacks] = useState([]);
    const [loadingFeedbacks, setLoadingFeedbacks] = useState(true); // состояние для загрузки отзывов

    useEffect(() => {
        const storedFeedbacks = localStorage.getItem('feedbacks');
        if (storedFeedbacks) {
            try {
                setFeedbacks(JSON.parse(storedFeedbacks));
            } catch (error) {
                console.error("Ошибка при парсинге данных отзывов:", error);
                setFeedbacks([]);
            }
        }
        setLoadingFeedbacks(false); // Устанавливаем false, когда отзывы загружены
    }, []);

    useEffect(() => {
      localStorage.setItem('feedbacks', JSON.stringify(feedbacks));
    }, [feedbacks]);

    const handleLoginSuccess = () => {
        setLoginState(true);
    };

    const handleLogout = () => {
        setLoginState(false);
    };

    const handleRegistrationSuccess = () => {
        // Logic after successful registration
    };

    const handleFeedbackSubmit = (newFeedback) => {
        setFeedbacks((prevFeedbacks) => {
            const updatedFeedbacks = [...prevFeedbacks, newFeedback];
            return updatedFeedbacks;
        });
    };

    if (authLoading || loadingFeedbacks) { // Отображаем загрузку, если authLoading или loadingFeedbacks true
        return <div>Загрузка...</div>;
    }

    return (
        <Router>
            <Header isLoggedIn={isLoggedIn} onLogout={handleLogout} />
            <Routes>
                <Route path="/registration" element={<RegistrationPage onRegisterSuccess={handleRegistrationSuccess} />} />
                <Route path="/login" element={<LoginPage onLoginSuccess={handleLoginSuccess} />} />
                <Route
                    path="/"
                    element={
                        isLoggedIn ? (
                            <HomePage feedbacks={feedbacks} onFeedbackSubmit={handleFeedbackSubmit} />
                        ) : (
                            <Navigate to="/login" replace />
                        )
                    }
                />
            </Routes>
        </Router>
    );
}

export default App;