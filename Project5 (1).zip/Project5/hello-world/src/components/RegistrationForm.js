import React, { useCallback } from 'react';
import { useForm } from 'react-hook-form';
import '../styles/RegistrationForm.css';

export const RegistrationForm = ({ onRegistrationSuccess }) => {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm();

    const onSubmit = useCallback((data) => {
        try {
            localStorage.setItem('user', JSON.stringify(data));
            onRegistrationSuccess();
        } catch (error) {
            console.error("Ошибка при регистрации:", error);
            alert("Ошибка при регистрации. Пожалуйста, попробуйте еще раз.");
        }
    }, [onRegistrationSuccess]); // Зависимости useCallback

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="registration-form">
            <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input
                    type="email"
                    id="email"
                    {...register('email', {
                        required: 'Email обязателен',
                        pattern: {
                            value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                            message: 'Неверный формат email'
                        }
                    })}
                />
                {errors.email && <span className="error-message">{errors.email.message}</span>}
            </div>

            <div className="form-group">
                <label htmlFor="password">Пароль:</label>
                <input
                    type="password"
                    id="password"
                    {...register('password', { required: 'Пароль обязателен', minLength: { value: 6, message: 'Пароль должен быть не менее 6 символов' } })}
                />
                {errors.password && <span className="error-message">{errors.password.message}</span>}
            </div>

            <button type="submit">Зарегистрироваться</button>
        </form>
    );
};