import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Header.css';

export const Header = ({ isLoggedIn, onLogout }) => {
    return (
        <header className="header">
            <nav>
                <ul>
                    <li><Link to="/">Главная</Link></li>
                    {isLoggedIn ? (
                        <li><button onClick={onLogout}>Выйти</button></li>
                    ) : (
                        <>
                            <li><Link to="/login">Вход</Link></li>
                            <li><Link to="/registration">Регистрация</Link></li>
                        </>
                    )}
                </ul>
            </nav>
        </header>
    );
};