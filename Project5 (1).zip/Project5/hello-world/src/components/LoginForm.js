import React from 'react';
import { useForm } from 'react-hook-form';
import '../styles/LoginForm.css';

export const LoginForm = ({ onLoginSuccess }) => {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm();

    const onSubmit = (data) => {
        const storedUserString = localStorage.getItem('user');
        if (storedUserString) {
            try {
                const storedUser = JSON.parse(storedUserString);
                if (JSON.stringify(storedUser) === JSON.stringify(data)) {
                    onLoginSuccess();
                    return;
                }
            } catch (error) {
                console.error("Ошибка при проверке учетных данных:", error);
                alert('Ошибка при проверке учетных данных.');
                return;
            }
        }
        alert('Неверный email или пароль');
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="login-form">
            <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input
                    type="email"
                    id="email"
                    {...register('email', {
                        required: 'Email обязателен',
                        pattern: {
                            value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                            message: 'Неверный формат email'
                        }
                    })}
                />
                {errors.email && <span className="error-message">{errors.email.message}</span>}
            </div>

            <div className="form-group">
                <label htmlFor="password">Пароль:</label>
                <input
                    type="password"
                    id="password"
                    {...register('password', { required: 'Пароль обязателен', minLength: { value: 6, message: 'Пароль должен быть не менее 6 символов' } })}
                />
                {errors.password && <span className="error-message">{errors.password.message}</span>}
            </div>

            <button type="submit">Войти</button>
        </form>
    );
};