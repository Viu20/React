import React from 'react';
import '../styles/AuthForm.css'; // Импортируйте общие стили

export const AuthForm = ({ children, onSubmit, formTitle }) => {
  return (
    <form onSubmit={onSubmit} className="auth-form">
      <h3>{formTitle}</h3>
      {children}
    </form>
  );
};