import React from 'react';
import { useForm } from 'react-hook-form';
import '../styles/FeedbackForm.css';

export const FeedbackForm = ({ onFeedbackSubmit }) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  const onSubmit = (data) => {
    onFeedbackSubmit(data);  // Отправляем данные отзыва в App.js
    reset(); // Очищаем поля формы после отправки
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="feedback-form">
      <h3>Оставьте свой отзыв</h3>
      <div className="form-group">
        <label htmlFor="name">Имя:</label>
        <input
          type="text"
          id="name"
          {...register('name', { required: 'Имя обязательно' })}
        />
        {errors.name && <span className="error-message">{errors.name.message}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          {...register('email', {
            required: 'Email обязателен',
            pattern: {
              value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
              message: 'Неверный формат email',
            },
          })}
        />
        {errors.email && <span className="error-message">{errors.email.message}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="feedback">Отзыв:</label>
        <textarea
          id="feedback"
          {...register('feedback', { required: 'Отзыв обязателен' })}
        />
        {errors.feedback && <span className="error-message">{errors.feedback.message}</span>}
      </div>

      <button type="submit">Отправить отзыв</button>
    </form>
  );
};