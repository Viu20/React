import React from 'react';
import '../styles/AuthForm.css'; // Импорт общих стилей

export const AuthLayout = ({ title, children }) => {
  return (
    <div className="auth-container">
      <h2>{title}</h2>
      {children}
    </div>
  );
};