import React from 'react';
import '../styles/FeedbackList.css';

export const FeedbackList = ({ feedbacks }) => {
  if (!feedbacks || feedbacks.length === 0) {
    return <p>Пока нет отзывов.</p>;
  }

  return (
    <div className="feedback-list">
      <h3>Отзывы:</h3>
      <ul>
        {feedbacks.map((feedback, index) => (
          <li key={index} className="feedback-item">
            <p><strong>{feedback.name}</strong> ({feedback.email}):</p>
            <p>{feedback.feedback}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};