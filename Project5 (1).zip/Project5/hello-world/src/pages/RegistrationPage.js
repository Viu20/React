import React from 'react';
import { RegistrationForm } from '../components/RegistrationForm';
import { useNavigate } from 'react-router-dom';

export const RegistrationPage = ({ onRegisterSuccess }) => {
  const navigate = useNavigate();

  const handleRegistrationSuccess = () => {
    onRegisterSuccess();  // Вызываем функцию из App.js для обновления состояния auth
    navigate('/login'); // Перенаправляем на страницу входа после успешной регистрации
  };

  return (
    <div>
      <h2>Регистрация</h2>
      <RegistrationForm onRegistrationSuccess={handleRegistrationSuccess} />
    </div>
  );
};