import React from 'react';
import { LoginForm } from '../components/LoginForm';
import { useNavigate } from 'react-router-dom';

export const LoginPage = ({ onLoginSuccess }) => {
  const navigate = useNavigate();

  const handleLoginSuccess = () => {
    onLoginSuccess();  // Вызываем функцию из App.js для обновления состояния auth
    navigate('/');     // Перенаправляем на главную страницу после успешного входа
  };

  return (
    <div>
      <h2>Вход</h2>
      <LoginForm onLoginSuccess={handleLoginSuccess} />
    </div>
  );
};