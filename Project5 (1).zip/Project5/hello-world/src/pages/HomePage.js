import React from 'react';
import { FeedbackForm } from '../components/FeedbackForm';
import { FeedbackList } from '../components/FeedbackList';

export const HomePage = ({ feedbacks, onFeedbackSubmit }) => {
  return (
    <div>
      <h2>Главная страница</h2>
      <FeedbackForm onFeedbackSubmit={onFeedbackSubmit} />
      <FeedbackList feedbacks={feedbacks} />
    </div>
  );
};