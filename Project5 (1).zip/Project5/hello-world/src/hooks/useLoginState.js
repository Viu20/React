import { useState, useEffect } from 'react';

const useLoginState = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // При монтировании хука проверяем, есть ли признак авторизации в localStorage
        const storedLoginSuccess = localStorage.getItem('loginSuccess');
        setIsLoggedIn(!!storedLoginSuccess); // Преобразуем в boolean
        setLoading(false);
    }, []);

    const setLoginState = (loginState) => {
        setIsLoggedIn(loginState);
        if (loginState) {
            localStorage.setItem('loginSuccess', 'true');
        } else {
            localStorage.removeItem('loginSuccess');
        }
    };

    return { isLoggedIn, setLoginState, loading };
};

export default useLoginState;